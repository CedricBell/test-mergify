Mergic
------

To run Mergify REST API, you need Python 3 and tox.

If you don't have `tox` installed, you can install it using: `pip install tox`.

You can then use `tox -e run` to launch the Web server. (Or `tox -e run-windows` on Windows)
