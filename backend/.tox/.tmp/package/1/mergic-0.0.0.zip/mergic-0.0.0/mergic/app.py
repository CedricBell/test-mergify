import datetime
import typing
import re


import flask

app = flask.Flask(__name__)


@app.route("/pull-requests/next-to-review", methods=["POST"])
def next_pr_to_review() -> typing.Any:
    if flask.request.json is None:
        flask.abort(400)

    pr_list = flask.request.json["pull_requests"]
    print(pr_list)

    return flask.jsonify(get_best_score_pr(pr_list))


def get_best_score_pr(pr_list):
    pr_best_score = None
    best_score = 0
    for i in range(1, len(pr_list)):
        current_score = computeScore(pr_list(i))
        if(best_score < current_score):
            pr_best_score = pr_list(i)
            best_score = current_score

    return pr_best_score


def computeScore(pr):
    print(pr)
    score = 0
    if pr.label == "urgent":
        score += 10
    if re.search("^[a-e]", pr.author) is not None:
        if datetime.datetime.today().weekday() == "Monday":
            score += 1
    if re.search("^[f-j]", pr.author) is not None:
        if datetime.datetime.today().weekday() == "Tueday":
            score += 1
    if re.search("^[k-o]", pr.author) is not None:
        if datetime.datetime.today().weekday() == "Wednesday":
            score += 1
    if re.search("^[p-t]", pr.author) is not None:
        if datetime.datetime.today().weekday() == "Thursday":
            score += 1
    if re.search("^[u-z]", pr.author) is not None:
        if datetime.datetime.today().weekday() == "Friday":
            score += 1
    if not pr.mergeable:
        score -= 2
    if pr.lines > 100:
        score += 1
    if pr.status == "draft":
        score -= 5

    print(score)
    return score


application = app
